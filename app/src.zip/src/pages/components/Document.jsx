import React from "react";
import "../styles/Document.css";

const Documents = () => {

  const documents = [
    {
      name: "Fire Safety Certificate.pdf",
      type: "Certificate",
      category: "Health & Safety",
      plant: "Mumbai Plant A",
      uploadedBy: "John Smith",
      date: "2026-03-25",
      size: "2.4 MB"
    },
    {
      name: "ISO 9001 Audit Report.pdf",
      type: "Report",
      category: "Quality Management",
      plant: "Delhi Plant B",
      uploadedBy: "Sarah Johnson",
      date: "2026-03-24",
      size: "5.1 MB"
    },
    {
      name: "Env. Compliance Checklist.xlsx",
      type: "Checklist",
      category: "Environmental",
      plant: "Bangalore Plant C",
      uploadedBy: "Michael Chen",
      date: "2026-03-22",
      size: "2.8 MB"
    },
    {
      name: "Labor Law Form.docx",
      type: "Form",
      category: "Statutory",
      plant: "Mumbai Plant A",
      uploadedBy: "Michael Chen",
      date: "2026-03-23",
      size: "2.8 MB"
    },
    {
      name: "Safety Training Records.pdf",
      type: "Record",
      category: "Health & Safety",
      plant: "Delhi Plant B",
      uploadedBy: "Robert Wilson",
      date: "2026-03-18",
      size: "3.7 MB"
    }
  ];

  const getTagClass = (type) => {
    return `tag ${type.toLowerCase()}`;
  };

  return (
    <>
      {/* Header */}
      <div className="doc-header">
        <h2>Documents</h2>
        <p>Manage compliance documents and files</p>
      </div>

      {/* Upload Box */}
      <div className="upload-box">
        <div className="upload-content">
          <div className="upload-icon">⬆</div>
          <p>Click to upload or drag and drop</p>
          <span>PDF, DOC, DOCX, XLS, XLSX (Max 50MB)</span>
          <button>Browse Files</button>
        </div>
      </div>

      {/* Filters */}
      <div className="filters">
        <input placeholder="Search documents..." />

        <select>
          <option>All Types</option>
        </select>

        <select>
          <option>All Categories</option>
        </select>

        <select>
          <option>All Plants</option>
        </select>

        <button className="light-btn">Date Range</button>
        <button className="light-btn">More filters</button>
      </div>

      {/* Table */}
      <div className="table-container">
        <table>
          <thead>
            <tr>
              <th>Document Name</th>
              <th>Type</th>
              <th>Category</th>
              <th>Plant</th>
              <th>Uploaded By</th>
              <th>Upload Date</th>
              <th>Size</th>
              <th>Actions</th>
            </tr>
          </thead>

          <tbody>
            {documents.map((doc, i) => (
              <tr key={i}>
                <td className="doc-name">📄 {doc.name}</td>
                <td><span className={getTagClass(doc.type)}>{doc.type}</span></td>
                <td>{doc.category}</td>
                <td>{doc.plant}</td>
                <td>{doc.uploadedBy}</td>
                <td>{doc.date}</td>
                <td>{doc.size}</td>
                <td className="actions">
                  ⬇ ✏ 🗑
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
};

export default Documents;