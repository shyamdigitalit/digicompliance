import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import "../styles/Setting.css";

const MasterForm = () => {
  const { type } = useParams();
  const navigate = useNavigate();

  return (
    <div className="master-card">

      <h3>Add {type.toUpperCase()}</h3>

      <div className="master-form">
        <input placeholder="Enter Name" />
        <input placeholder="Enter Code" />
      </div>

      <div style={{ marginTop: "20px" }}>
        <button className="dark-btn">Save</button>

        <button
          className="light-btn"
          onClick={() => navigate(-1)}
          style={{ marginLeft: "10px" }}
        >
          Cancel
        </button>
      </div>

    </div>
  );
};

export default MasterForm;