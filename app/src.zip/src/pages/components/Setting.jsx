import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/Setting.css";

const masterList = [
  "department",
  "designation",
  "plant",
  "compliancetype",
  "compliancecategory",
  "compliancefrequency",
  "criticality",
  "penaltytype"
];

const Settings = () => {
  const [activeTab, setActiveTab] = useState("Profile");
  const [showMasters, setShowMasters] = useState(false);

  const navigate = useNavigate();

  return (
    <>
      {/* Header */}
      <div className="settings-header">
        <h2>Settings</h2>
        <p>Manage your account and system preferences</p>
      </div>

      <div className="settings-container">

        {/* Sidebar */}
        <div className="settings-sidebar">

          {["Profile", "Notifications", "Security", "Organization", "System"].map((item) => (
            <div
              key={item}
              className={`settings-item ${activeTab === item ? "active" : ""}`}
              onClick={() => {
                setActiveTab(item);
                setShowMasters(false);
              }}
            >
              {item}
            </div>
          ))}

          {/* Masters */}
          <div
            className="settings-item"
            onClick={() => {
              setActiveTab("Masters");
              setShowMasters(!showMasters);
            }}
          >
            Masters ▾
          </div>

          {/* Submenu */}
          {showMasters && (
            <div className="master-submenu">
              {masterList.map((item) => (
                <div
                  key={item}
                  className="settings-subitem"
                  onClick={() => navigate(`/setting/masters/${item}`)}
                >
                  {item.toUpperCase()}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Content */}
        <div className="settings-content">

          {/* PROFILE */}
          {activeTab === "Profile" && (
            <div className="profile-card">

              <h3>Profile Information</h3>
              <p>Update your personal information and profile details</p>

              <div className="profile-top">
                <div className="avatar">JD</div>
                <button className="light-btn">Change Photo</button>
              </div>

              <hr />

              <div className="form-grid">

                <div>
                  <label>First Name</label>
                  <input value="John" readOnly />
                </div>

                <div>
                  <label>Last Name</label>
                  <input value="Doe" readOnly />
                </div>

                <div>
                  <label>Email Address</label>
                  <input value="john.doe@company.com" readOnly />
                </div>

                <div>
                  <label>Phone Number</label>
                  <input value="+1 (555) 123-4567" readOnly />
                </div>

                <div>
                  <label>Company Name</label>
                  <input value="Industrial Solutions Inc." readOnly />
                </div>

                <div>
                  <label>Department</label>
                  <select>
                    <option>Operations</option>
                  </select>
                </div>

                <div>
                  <label>Default Plant</label>
                  <select>
                    <option>Mumbai Plant A</option>
                  </select>
                </div>

                <div>
                  <label>Time Zone</label>
                  <select>
                    <option>GMT +5:30 (India)</option>
                  </select>
                </div>

              </div>
            </div>
          )}

        </div>
      </div>
    </>
  );
};

export default Settings;