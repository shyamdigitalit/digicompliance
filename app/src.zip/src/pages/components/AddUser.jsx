import React, { useState } from "react";
import "../styles/AddUser.css";

const AddUser = ({ onCancel, onSubmit }) => {
    const [form, setForm] = useState({
        username: "",
        name: "",          
        email: "",
        role: "",
        plant: "",
        description: ""   
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setForm((prev) => ({ ...prev, [name]: value }));
    };

    const handleSubmit = () => {
        if (!form.username || !form.name || !form.email || !form.role || !form.plant) {
            alert("Please fill all required fields");
            return;
        }

        onSubmit(form);
    };

    return (
        <div className="add-page">

            {/* HEADER */}
            <div className="header">
                <div>
                    <h2>Add User</h2> 
                    <p>Create and manage users</p>
                </div>
            </div>

            {/* FORM CARD */}
            <div className="form-card">

                {/* SECTION 1 */}
                <div className="section">
                    <h3>Basic Information</h3>

                    <div className="form-grid">
                        <div className="form-group">
                            <label>Username</label>
                            <input
                                type="text"
                                name="username"
                                value={form.username}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="form-group">
                            <label>Name</label>
                            <input
                                type="text"
                                name="name"  
                                value={form.name}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="form-group">
                            <label>Email Address</label>
                            <input
                                name="email"
                                value={form.email}
                                onChange={handleChange}
                            />
                        </div>

                        <div className="form-group">
                            <label>Role</label>
                            <input
                                name="role"
                                value={form.role}  
                                onChange={handleChange}
                            />
                        </div>

                        <div className="form-group">
                            <label>Plant</label>
                            <input
                                name="plant"
                                value={form.plant}
                                onChange={handleChange}
                            />
                        </div>
                    </div>
                </div>

                {/* SECTION 2 */}
                <div className="section">
                    <h3>Remarks</h3>

                    <div className="form-group full">
                        <label>Details</label>
                        <textarea
                            name="description"
                            value={form.description}
                            onChange={handleChange}
                            rows="4"
                        />
                    </div>
                </div>

                {/* ACTIONS */}
                <div className="form-actions">
                    <button className="light-btn" onClick={onCancel}>Cancel</button>
                    <button className="dark-btn" onClick={handleSubmit}>Submit</button>
                </div>

            </div>
        </div>
    );
};

export default AddUser;