import React from "react";
import { useParams, useNavigate } from "react-router-dom";
import "../styles/Setting.css";

const MasterList = () => {
  const { type } = useParams();
  const navigate = useNavigate();

  const data = [
    {
      name: "Operations",
      code: "OPS",
      status: "Active",
      createdAt: "2026-03-01",
      updatedAt: "2026-03-10"
    }
  ];

  return (
    <div className="master-card">

      <div className="master-header">
        <h3>{type.toUpperCase()}</h3>

        <button
          className="dark-btn"
          onClick={() => navigate(`/setting/masters/${type}/add`)}
        >
          + Add
        </button>
      </div>

      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Code</th>
            <th>Status</th>
            <th>Created At</th>
            <th>Updated At</th>
          </tr>
        </thead>

        <tbody>
          {data.map((item, i) => (
            <tr key={i}>
              <td>{item.name}</td>
              <td>{item.code}</td>
              <td><span className="tag green">{item.status}</span></td>
              <td>{item.createdAt}</td>
              <td>{item.updatedAt}</td>
            </tr>
          ))}
        </tbody>
      </table>

    </div>
  );
};

export default MasterList;