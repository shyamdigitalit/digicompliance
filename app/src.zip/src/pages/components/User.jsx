import React from "react";
import "../styles/User.css";
import AddUser from "./AddUser";

const Users = () => {

    const [showAddForm, setShowAddForm] = React.useState(false);

    const [data, setData] = React.useState([
        {
            username: "jsmith",
            name: "John Smith",
            email: "john.smith@company.com",
            role: "Department Manager",
            plant: "Mumbai Plant A"
        },
        {
            username: "sjohnson",
            name: "Sarah Johnson",
            email: "sarah.johnson@company.com",
            role: "Plant Head",
            plant: "Delhi Plant B"
        },
        {
            username: "mchen",
            name: "Michael Chen",
            email: "michael.chen@company.com",
            role: "Compliance Officer",
            plant: "Mumbai Plant A"
        },
        {
            username: "edavis",
            name: "Emily Davis",
            email: "emily.davis@company.com",
            role: "Quality Manager",
            plant: "Bangalore Plant C"
        },
        {
            username: "rwilson",
            name: "Robert Wilson",
            email: "robert.wilson@company.com",
            role: "HR Manager",
            plant: "Delhi Plant B"
        },
        {
            username: "lbrown",
            name: "Lisa Brown",
            email: "lisa.brown@company.com",
            role: "Safety Officer",
            plant: "Mumbai Plant A"
        },
        {
            username: "dgarcia",
            name: "David Garcia",
            email: "david.garcia@company.com",
            role: "Operations Manager",
            plant: "Bangalore Plant C"
        },
        {
            username: "amartin",
            name: "Anna Martin",
            email: "anna.martin@company.com",
            role: "Environment Manager",
            plant: "Delhi Plant B"
        }
    ]);

    const getRoleClass = (role) => {
        if (role.includes("Manager")) return "tag blue";
        if (role.includes("Head")) return "tag purple";
        if (role.includes("Officer")) return "tag green";
        return "tag orange";
    };

    const handleAddSubmit = (formData) => {

        console.log("New User:", formData);

        setData(prev => [...prev, {
            id: `USR-${String(prev.length + 1).padStart(3, "0")}`,
            username: formData.username,
            name: formData.name, // ✅ fixed
            email: formData.email,
            role: formData.role,
            plant: formData.plant
        }]);

        setShowAddForm(false);
    };

    const handleCancel = () => {
        setShowAddForm(false);
    };

    return (
        <>
            {showAddForm ? (
                <AddUser
                    onCancel={handleCancel}
                    onSubmit={handleAddSubmit}
                />
            ) : (
                <>
                    {/* Header */}
                    <div className="user-header">
                        <h2>User Management</h2>
                        <p>Manage users and their access to the compliance system</p>
                    </div>

                    {/* Filters */}
                    <div className="user-filters">
                        <input placeholder="Search by name, username or email..." />

                        <select>
                            <option>All Roles</option>
                        </select>

                        <select>
                            <option>All Plants</option>
                        </select>

                        <button className="light-btn">Date Range</button>
                        <button className="light-btn">More filters</button>

                        <button
                            className="add-btn"
                            onClick={() => setShowAddForm(true)}>
                            + Add User
                        </button>
                    </div>

                    {/* Table */}
                    <div className="user-table">
                        <table>
                            <thead>
                                <tr>
                                    <th>Username</th>
                                    <th>Full name</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                    <th>Plant</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>

                            <tbody>
                                {data.map((user, i) => ( // ✅ fixed
                                    <tr key={i}>
                                        <td className="link">{user.username}</td>
                                        <td>{user.name}</td>
                                        <td>{user.email}</td>
                                        <td>
                                            <span className={getRoleClass(user.role)}>
                                                {user.role}
                                            </span>
                                        </td>
                                        <td>{user.plant}</td>
                                        <td className="edit">Edit</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>

                    {/* Footer */}
                    <div className="table-footer">
                        <span>Showing 1 to {data.length} of {data.length} users</span>
                        <div>
                            <button className="light-btn">Previous</button>
                            <button className="light-btn">Next</button>
                        </div>
                    </div>
                </>
            )}
        </>
    );
};

export default Users;